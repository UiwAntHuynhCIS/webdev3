let DATA;
fetch('data.php').then(r => r.json()).then(d => { DATA = d; });

const champs = [...document.querySelectorAll('.champ')];
const zone = document.getElementById('team-zone');
const output = document.getElementById('output');

// ---- dragging (replaces Dragger.cs) ----
champs.forEach(el => {
  el.dx = 0; el.dy = 0;
  el.addEventListener('pointerdown', e => {
    el.setPointerCapture(e.pointerId);
    el.classList.add('dragging');
    el.sx = e.clientX - el.dx; el.sy = e.clientY - el.dy;
  });
  el.addEventListener('pointermove', e => {
    if (!el.hasPointerCapture(e.pointerId)) return;
    el.dx = e.clientX - el.sx; el.dy = e.clientY - el.sy;
    el.style.left = el.dx + 'px'; el.style.top = el.dy + 'px';
  });
  el.addEventListener('pointerup', () => el.classList.remove('dragging'));
});

// ---- helpers ----
function resetPositions() {
  champs.forEach(el => { el.dx = el.dy = 0; el.style.left = el.style.top = '0px'; });
}
function inZone(el) {
  const a = zone.getBoundingClientRect(), b = el.getBoundingClientRect();
  return !(b.right < a.left || b.left > a.right || b.bottom < a.top || b.top > a.bottom);
}

// ---- Show (ShowBTN_Click) ----
document.getElementById('showBtn').onclick = () => {
  const team = champs.filter(el => !el.classList.contains('hidden') && inZone(el)).map(el => el.dataset.name);
  const counts = {};
  for (const group of [DATA.classTraits, DATA.originTraits])
    for (const [trait, members] of Object.entries(group))
      team.forEach(n => { if (members.includes(n)) counts[trait] = (counts[trait] || 0) + 1; });
  const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  output.textContent = team.map(n => 'Champion: ' + n).join('\n') +
    '\n\nTrait Counts:\n' + sorted.map(([t, n]) => t + ': ' + n).join('\n');
};

// ---- Exclude (button1_Click) ----
document.getElementById('excludeBtn').onclick = () => {
  resetPositions();
  champs.forEach(el => el.classList.remove('hidden'));
  document.querySelectorAll('.excl:checked').forEach(cb =>
    DATA.originTraits[cb.value].forEach(name =>
      document.querySelector(`.champ[data-name="${name}"]`)?.classList.add('hidden')));
};

// ---- Reset (ResetBTN_Click) ----
document.getElementById('resetBtn').onclick = () => {
  resetPositions();
  champs.forEach(el => el.classList.remove('hidden'));
  document.querySelectorAll('.excl').forEach(cb => cb.checked = false);
  output.textContent = '';
};

// ---- Saved comps (talks to comps.php / tft_comps database) ----
const msg = document.getElementById('msg');
const compsList = document.getElementById('comps');

async function api(action, body) {
  const r = await fetch('comps.php?action=' + action, body ? {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
  } : undefined);
  const j = await r.json();
  if (!r.ok) throw new Error(j.error || 'Request failed');
  return j;
}

function loadComp(names) {
  resetPositions();
  champs.forEach(el => el.classList.remove('hidden'));
  const z = zone.getBoundingClientRect();
  names.forEach((n, i) => {
    const el = champs.find(c => c.dataset.name === n); if (!el) return;
    const home = el.getBoundingClientRect();           // natural slot position (offset is 0 after reset)
    el.dx = z.left + 10 + (i % 15) * 58 - home.left;
    el.dy = z.top + 10 + Math.floor(i / 15) * 63 - home.top;
    el.style.left = el.dx + 'px'; el.style.top = el.dy + 'px';
  });
}

async function refreshComps() {
  const comps = await api('list');
  compsList.innerHTML = '';
  comps.forEach(c => {
    const li = document.createElement('li');
    const mk = (cls, txt) => { const s = document.createElement('span'); s.className = cls; s.textContent = txt; return s; };
    const load = document.createElement('button'); load.textContent = 'Load'; load.onclick = () => loadComp(c.champions);
    const del = document.createElement('button'); del.textContent = 'Delete';
    del.onclick = async () => { await api('delete', { id: c.id }); refreshComps(); };
    li.append(mk('cname', c.name), mk('cchamps', c.champions.join(', ')), load, del);
    compsList.append(li);
  });
}

document.getElementById('saveBtn').onclick = async () => {
  const team = champs.filter(el => !el.classList.contains('hidden') && inZone(el)).map(el => el.dataset.name);
  try {
    await api('save', { name: document.getElementById('compName').value, champions: team });
    msg.textContent = 'Saved!'; document.getElementById('compName').value = '';
    refreshComps();
  } catch (e) { msg.textContent = e.message; }
};
refreshComps();
